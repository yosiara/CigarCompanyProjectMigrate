# -*- coding: utf-8 -*-
from odoo import api, fields, models, tools
from odoo.exceptions import ValidationError


class ProductiveSection(models.Model):
    _name = 'process_control.productive_section'
    _description = 'Productive Section'
    _order = 'name'

    name = fields.Char('Name *', required=True, default='Productive Section ')
    productive_section_plan_id = fields.Many2one('process_control.productive_section_plan', string='Plan *', required=True)
    active = fields.Boolean(string='Active', default=True)
    productive_line_ids = fields.One2many('process_control.productive_line', inverse_name='productive_section_id', string='Productive Lines')

    _sql_constraints = [
        ('name_uniq', 'unique(name)', 'The production section name must be unique!'),
    ]

    # def _get_productions_code(self):
    #     connexion = self.env['process_control.db_production_connector'].search([], limit=1)
    #     #connexion.ensure_one()
    #     res = []
    #     if connexion:
    #         try:
    #             conn = connexion.connect()
    #             cursor = conn.cursor()
    #             cursor.execute('''SELECT 'id', descripcion FROM cd_modulo WHERE id > 0 ORDER BY id''')
    #             for row in cursor:
    #                 res.append((str(row[0]), str(row[1])))
    #         except Exception:
    #             pass
    #     return res

    # @api.constrains('productive_line_ids')
    # def check_productive_line_just_in_one_section(self):
    #     for productive_section_lines in self.productive_line_ids:
    #         lines_in_system = self.env['process_control.productive_section_lines'].search(
    #             [('productive_line.id', '=', productive_section_lines.productive_line.id)], limit=2)
    #         if len(lines_in_system) > 1:
    #             raise ValidationError(
    #                 u'La línea productiva: '' + tools.ustr(
    #                     productive_section_lines.productive_line.name)
    #                 + u'' ya ha sido añadida en la Modulo: '' +
    #                 tools.ustr(lines_in_system[0].productive_section_id.name) + ''')

    # def calculate_cdt(self, start_date=None, end_date=None, turn=None):
    #     self.ensure_one()
    #     domain = [('productive_section_id', '=', self.id)]
    #     if start_date and end_date:
    #         domain.append(('date', '<=', end_date))
    #         domain.append(('date', '>=', start_date))
    #     else:
    #         raise ValidationError('El CDT debe calcularse en un rango de fechas.')

    #     if turn:
    #         domain.append(('turn_calendar_id', '=', turn))

    #     count_lines = len(self.productive_line_ids)
    #     control_models = self.env['process_control.tech_control'].search(domain)

    #     cdt, sum_plan_time, sum_time_interruption, time_n_j = 0.00, 0.00, 0.00, 0.00

    #     for control_model in control_models:
    #         sum_plan_time += control_model.plan_time * 60
    #         for interruption in control_model.interruption_ids:
    #             if not interruption.productive_line_id:
    #                 sum_time_interruption += interruption.time * count_lines
    #             else:
    #                 sum_time_interruption += interruption.time

    #     if sum_plan_time and count_lines > 0.00:
    #         time_n_j = sum_plan_time - (sum_time_interruption / count_lines)
    #         if time_n_j > 0:
    #             cdt = round(((sum_plan_time - (sum_time_interruption / count_lines)) / sum_plan_time) * 100, 2)
    #         else:
    #             cdt = round(((sum_plan_time - ((sum_time_interruption / count_lines) + time_n_j)) / sum_plan_time) * 100, 2)

    #     return cdt

    # def calculate_efficiency(self, start_date=None, end_date=None, turn=None):
    #     self.ensure_one()
    #     domain = [('productive_section_id', '=', self.id)]
    #     if start_date and end_date:
    #         domain.append(('date', '<=', end_date))
    #         domain.append(('date', '>=', start_date))
    #     else:
    #         raise ValidationError('La eficiencia productiva debe calcularse en un rango de fechas.')

    #     if turn:
    #         domain.append(('turn_calendar_id', '=', turn))

    #     control_models = self.env['process_control.tech_control'].search(domain)

    #     production_done, efficiency, time_planned, productive_capacity, productividad_real = (0.00, 0.00, 0.00, 0.00, 0.00)

    #     for control_model in control_models:
    #         production_done += control_model.production_in_proccess_control
    #         # productive_capacity += control_model.productive_capacity
    #         productive_capacity += self.get_efficiency_plan().productive_capacity
    #         productividad_real += control_model.plan_time * 60 * self.get_efficiency_plan().productive_capacity  # control_model.productive_capacity
    #     if productive_capacity and production_done > 0.00:
    #         efficiency = round(((production_done * 10000.00) / productividad_real) * 100.00, 2)

    #     return efficiency

    # #@api.model_create_multi
    # def get_efficiency_plan(self):
    #     self.ensure_one()
    #     return self.env['process_control.productive_section_plan'].search([('productive_section_ids', 'in', self.id), ('active', '=', True)])

    # def get_ind_rejection(self, start_date, end_date, turn=False):
    #     suma_ind = 0.00
    #     for line in self.productive_line_ids:
    #         suma_ind += line.get_reg_ind(start_date, end_date, turn, line.productive_line.id)
    #     # return round(suma_ind/len(self.productive_line_ids), 3)
    #     return round(suma_ind / self.get_efficiency_plan().quantity_line, 3)
